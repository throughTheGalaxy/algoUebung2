package sort;

import data.Student;

public interface Comparator<T> {
    int compare(Student o1, Student o2);
}