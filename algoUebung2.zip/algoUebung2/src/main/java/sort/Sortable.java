package sort;

import data.Student;
import lists.IListable;

public interface Sortable<T> {
    IListable<Student> sort(IListable<Student> list, Comparator<Student> comp);
}
