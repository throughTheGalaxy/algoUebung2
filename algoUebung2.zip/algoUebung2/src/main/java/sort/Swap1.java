package sort;

import data.Student;
import lists.IListable;

import java.util.List;

public class Swap1 <T>{

    protected void swap(List<Student> list, int i, int j) {
        Student memorizedObject = list.get(i);
        list.set(i, list.get(j));
        list.set(j, memorizedObject);
    }

}