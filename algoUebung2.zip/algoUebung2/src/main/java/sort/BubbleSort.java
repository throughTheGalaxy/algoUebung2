package sort;


import data.*;
import lists.*;

import java.util.List;


public class BubbleSort<T> extends Swap<T> implements Sortable<T> {

    @Override
    public IListable<Student> sort(IListable<Student> list, Comparator<Student> comp) {
        for (int i = 1; i < list.size(); i++) {
            for (int e = 0; e < list.size() - i; e++) {
                if (comp.compare(list.get(e), list.get(e + 1)) > 0) { // Sortiert Aufsteigend > Absteigend <
                    swap(list, e, e + 1);
                }
            }
        }
        return list;
    }
}